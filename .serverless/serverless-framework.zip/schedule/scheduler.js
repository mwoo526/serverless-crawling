const cron = require('node-cron');
const { updateEleven, updateGmarket, updateAuction, updateWemaker, updateSSG } = require('../route/model/updateMarket');
const { listSearchTest } = require('../database/select');
const { get, map, go } = require('../js/fp');

let scheduler = function () {

    cron.schedule('00 00 00 * * *',async function () {

        const data = go(
            await listSearchTest(),
            map(get('product_search')));
        console.log(data);

        try {
            for(let i = 0; i < data.length; i++) {
                console.log(`-----[${data[i]}] 업데이트------`);
                await updateEleven(data[i]);
                await updateGmarket(data[i]);
                await updateAuction(data[i]);
                await updateWemaker(data[i]);
                await updateSSG(data[i]);
            }
            console.log("-----스케줄링 종료------");
        } catch (e) {
            console.log(e.message);
        }
    },{
        timezone: "Asia/Seoul"
    });

};


module.exports = { scheduler };