const { createEleven, createGmarket, createAuction, createWemaker, createSSG } = require('./model/createMarket');

app.post('/dev/create', async (req, res)=> {

    let searchTerm = req.body.productName;
    try{
        await createEleven(searchTerm);
        await createGmarket(searchTerm);
        await createAuction(searchTerm);
        await createWemaker(searchTerm);
        await createSSG(searchTerm);
        res.render('result', {
            searchTerm: searchTerm
        })
        ;

    } catch (err) {
        switch (err) {
            case 'This data is existed':
                res.render('err', {
                    searchTerm: '이미 존재하는 상품입니다.'
            });
                break;

            default:
                res.render('err',{
                    searchTerm: err.message
                });
        }
    }


});

