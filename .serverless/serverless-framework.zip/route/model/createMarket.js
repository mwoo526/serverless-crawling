const { create_data } = require('../../database/insert');
const { elevenCrawling, gmarketCrawling, auctionCrawling, wemakerCrawling, ssgCrawling } = require('../../util/crawling');
const { checkTest } = require('../../database/select');



const createEleven = (searchTerm) => {
    return new Promise(async (resolve, reject) => {
        try {
            const check = await checkTest("eleven",searchTerm);

            if (check[0] == null) {

                const data = await elevenCrawling(searchTerm);
                console.log("11 번가 조회 상품 개수: " + data.length); // 80개

                await create_data(data);
                resolve(searchTerm);
            }

            reject(`This data is existed`);
        } catch (e) {
            reject(e.message);
        }
    });
}


const createGmarket = (searchTerm) => {
    return new Promise(async (resolve, reject) => {
        try {
            const check = await checkTest("gmarket",searchTerm);

            if (check[0] == null) {

                const data = await gmarketCrawling(searchTerm);
                console.log("g마켓 조회 상품 개수: " + data.length); // 68개

                await create_data(data);
                resolve(searchTerm);
            }

            reject(`This data is existed`);
        } catch (e) {
            reject(e.message);
        }
    });
}

const createAuction = (searchTerm) => {
    return new Promise(async (resolve, reject) => {
        try {
            const check = await checkTest("auction",searchTerm);

            if (check[0] == null) {
                const data = await auctionCrawling(searchTerm);
                console.log("옥션 조회 상품 개수: " + data.length); // 80개

                await create_data(data);
                resolve(searchTerm);
            }

            reject(`This data is existed`);
        } catch (e) {
            reject(e.message);
        }
    });
}

const createWemaker = (searchTerm) => {
    return new Promise(async (resolve, reject) => {
        try {
            const check = await checkTest("wemaker",searchTerm);

            if (check[0] == null) {
                const data = await wemakerCrawling(searchTerm);
                console.log("위메프 조회 상품 개수: " + data.length); // 30개

                await create_data(data);
                resolve(searchTerm);
            }

            reject(`This data is existed`);
        } catch (e) {
            reject(e.message);
        }
    });
}

const createSSG = (searchTerm) => {
    return new Promise(async (resolve, reject) => {
        try {
            const check = await checkTest("SSG",searchTerm);

            if (check[0] == null) {
                const data = await ssgCrawling(searchTerm);
                console.log("SSG 조회 상품 개수: " + data.length); // 80개

                await create_data(data);
                resolve(searchTerm);
            }

            reject(`This data is existed`);
        } catch (e) {
            reject(e.message);
        }
    });
}

module.exports = {createEleven, createGmarket, createAuction, createWemaker, createSSG};