const { listTest} = require('../../database/select');
const { updateData } = require('../../database/update');
const { elevenCrawling, gmarketCrawling, auctionCrawling, wemakerCrawling, ssgCrawling } = require('../../util/crawling');

const updateEleven = (productSearch) => {
    return new Promise(async (resolve, reject) => {
        try{
            const data = await elevenCrawling(productSearch);

            const product = await listTest("eleven", productSearch);
            await updateData(data,product);
            console.log(`11번가 [${productSearch}] 업데이트`);
            resolve(productSearch);

        }catch (e) {
            reject(e.message);
        }
    })

}

const updateGmarket = (productSearch) => {
    return new Promise(async (resolve, reject) => {
        try{
            const data = await gmarketCrawling(productSearch);

            const product = await listTest("gmarket", productSearch);
            await updateData(data,product);
            console.log(`g마켓 [${productSearch}] 업데이트`);
            resolve(productSearch);

        }catch (e) {
            reject(e.message);
        }
    })

}

const updateAuction = (productSearch) => {
    return new Promise(async (resolve, reject) => {
        try{
            const data = await auctionCrawling(productSearch);

            const product = await listTest("auction", productSearch);
            await updateData(data,product);
            //console.log(`옥션 [${productSearch}] 업데이트`);
            resolve(productSearch);

        }catch (e) {
            reject(e.message);
        }
    })

}

const updateWemaker = (productSearch) => {
    return new Promise(async (resolve, reject) => {
        try{
            const data = await wemakerCrawling(productSearch);

            const product = await listTest("wemaker", productSearch);
            await updateData(data,product);
            console.log(`위메프 [${productSearch}] 업데이트`);
            resolve(productSearch);

        }catch (e) {
            reject(e.message);
        }
    })

}

const updateSSG = (productSearch) => {
    return new Promise(async (resolve, reject) => {
        try{
            const data = await ssgCrawling(productSearch);

            const product = await listTest("ssg", productSearch);
            await updateData(data,product);
            console.log(`SSG [${productSearch}] 업데이트`);
            resolve(productSearch);

        }catch (e) {
            reject(e.message);
        }
    })

}



module.exports = { updateEleven, updateGmarket, updateAuction, updateWemaker, updateSSG };