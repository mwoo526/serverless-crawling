const { QUERY } = require('./util');

const listTest = (commerce, search) => {
    return QUERY `
    SELECT * FROM test WHERE product_commerce = ${commerce} AND product_search = ${search} ORDER BY id 
    `;
}

const listSearchTest = () => {
    return QUERY`
    SELECT DISTINCT product_search FROM test
    `
}

const checkTest = (commerce, search) => {
    return QUERY `
    SELECT * FROM test WHERE product_commerce = ${commerce} AND product_search = ${search} 
    `;
}

const checkUser = (user) => {
    return QUERY`
    SELECT * FROM admin_user WHERE admin_id = ${user.admin_id} AND admin_pw = ${user.admin_pw}
    `;
}

module.exports = { listTest, listSearchTest, checkTest, checkUser};
