(async () => {
    const {listTest, checkTest, checkUser } = require('./select');
    const { updateData } = require('./update');
    const { objectEqual} = require('../util/objectEqual');

    let data = { product_url: 'http://item.gmarket.co.kr/Item?goodscode=160761785&pos_shop_cd=SH&pos_class_cd=111111111&pos_class_kind=T&keyword_seqno=16725494841&search_keyword=%ec%95%9e%eb%8b%a4%eb%a6%ac%ec%82%b4',
        product_name: '국내산암돼지/앞다리살400g/목살400g/삼겹살400g',
        product_price: '6,800',
        product_image: 'http://gdimg.gmarket.co.kr/160761785/still/160?ver=0',
        product_commerce: 'gmarket',
        product_search: '앞다리살' };


    let product = { id: 14982,
        product_name: '국내산암돼지/앞다리살400g/목살400g/삼겹살400g',
        product_image: 'http://gdimg.gmarket.co.kr/160761785/still/160?ver=0',
        product_url: 'http://item.gmarket.co.kr/Item?goodscode=160761785&pos_shop_cd=SH&pos_class_cd=111111111&pos_class_kind=T&keyword_seqno=16725273067&search_keyword=%ec%95%9e%eb%8b%a4%eb%a6%ac%ec%82%b4',
        product_price: '6,800',
        product_commerce: 'gmarket',
        product_search: '앞다리살' };

    //let user = { admin_id: 'test@gmail.com', admin_pw: 'testpw' };
    let user = { admin_id: 'dev@itda.io', admin_pw: 'Dltek123!' };


    let check = await checkUser(user);
    //let check = await objectEqual(data, product);


    console.log(check);


})();