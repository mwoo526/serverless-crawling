const { QUERY } = require('./util');


const insert_product = (input) => {
    return QUERY`
    INSERT INTO tb_commerce ("productName", "productPrice", "productImage", "productUrl", "productCommerce" ) 
    values (${input.productName}, ${input.productPrice}, ${input.productImage}, ${input.productUrl}, ${input.productCommerce})
    `;
}


const create_test = function(input){
    return QUERY`
    INSERT INTO test ("product_name", "product_price", "product_image", "product_url", "product_commerce", "product_search") 
    values (${input.product_name}, ${input.product_price}, ${input.product_image}, ${input.product_url}, ${input.product_commerce}, ${input.product_search})

`;
}

const create_data = async (list) => {
    for(let i = 0; i< list.length; i++){
        await create_test(list[i])
            .catch(e => console.log(`에러 요소: ${i} , 에러 메세지: ${e.message}`));
    }
}
module.exports = {
    create_test, create_data
}